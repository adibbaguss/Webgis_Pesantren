@extends('layouts.app')
@section('content')

<div class="container vh-100">
    <div class="mt-5 pt-5">
        
    </div>
</div>
    
@endsection